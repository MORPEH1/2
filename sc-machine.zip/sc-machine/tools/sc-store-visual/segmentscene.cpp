#include "segmentscene.h"

SegmentScene::SegmentScene(QObject *parent) :
    QGraphicsScene(parent)
{
}

SegmentScene::~SegmentScene()
{

}
