#ifndef SEGMENTSCENE_H
#define SEGMENTSCENE_H

#include <QGraphicsScene>

class SegmentScene : public QGraphicsScene
{
    Q_OBJECT
public:
    explicit SegmentScene(QObject *parent = 0);
    virtual ~SegmentScene();
    
signals:
    
public slots:
    
};

#endif // SEGMENTSCENE_H
