#define REDIS_GIT_SHA1 "d1a57ecf"
#define REDIS_GIT_DIRTY "0"
#define REDIS_BUILD_ID "developer-VirtualBox-1443084088"
